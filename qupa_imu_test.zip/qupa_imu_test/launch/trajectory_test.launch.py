"""
trajectory_test.launch.py — test the polygon trajectory with the MPU6050.

Launches (all under /<namespace>):
  motor_node               (from qupa_hardware, if with_motors:=true)
  mpu6050/mpu6050_node     → /<ns>/mpu6050/imu/data_raw, /<ns>/mpu6050/tare
  polygon_trajectory_node  → waits for /<ns>/trajectory/start

If hardware.launch.py is already running motor_node, use with_motors:=false.

Usage:
  ros2 launch qupa_imu_test trajectory_test.launch.py
  ros2 launch qupa_imu_test trajectory_test.launch.py namespace:=qupa_3B with_motors:=false
  ros2 service call /qupa_3A/trajectory/start std_srvs/srv/Trigger
  ros2 topic echo /qupa_3A/trajectory/result
"""

import os
import yaml

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg    = get_package_share_directory('qupa_imu_test')
    hw_pkg = get_package_share_directory('qupa_hardware')

    def _load(file_key, yaml_path):
        with open(yaml_path, 'r') as f:
            cfg = yaml.safe_load(f)
        return cfg.get(file_key, {}).get('ros__parameters', {})

    motor_params = _load('motor_node',              os.path.join(hw_pkg, 'config', 'motor.yaml'))
    imu_params   = _load('mpu6050_node',            os.path.join(pkg, 'config', 'mpu6050.yaml'))
    traj_params  = _load('polygon_trajectory_node', os.path.join(pkg, 'config', 'polygon_trajectory.yaml'))

    ns          = LaunchConfiguration('namespace')
    imu_ns      = LaunchConfiguration('imu_namespace')
    with_motors = LaunchConfiguration('with_motors')

    motor_node = Node(
        package='qupa_hardware',
        executable='motor_driver',
        name='motor_node',
        namespace=ns,
        output='screen',
        parameters=[motor_params],
        condition=IfCondition(with_motors),
    )

    imu_node = Node(
        package='qupa_imu_test',
        executable='mpu6050',
        name='mpu6050_node',
        namespace=[ns, '/', imu_ns],
        output='screen',
        parameters=[imu_params, {'frame_id': [ns, '/imu_link']}],
    )

    traj_node = Node(
        package='qupa_imu_test',
        executable='polygon_trajectory',
        name='polygon_trajectory_node',
        namespace=ns,
        output='screen',
        parameters=[traj_params, {
            'imu_topic':    [imu_ns, '/imu/data_raw'],
            'tare_service': [imu_ns, '/tare'],
        }],
    )

    return LaunchDescription([
        DeclareLaunchArgument('namespace', default_value='qupa_3A',
                              description='Robot namespace'),
        DeclareLaunchArgument('imu_namespace', default_value='mpu6050',
                              description='Sub-namespace for the MPU6050'),
        DeclareLaunchArgument('with_motors', default_value='true',
                              description='Also start motor_node from qupa_hardware'),

        motor_node,
        TimerAction(period=2.0, actions=[imu_node]),    # robot still: tare at startup
        TimerAction(period=5.0, actions=[traj_node]),
    ])
