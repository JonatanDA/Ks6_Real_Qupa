#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
polygon_trajectory_node — ROS2 Jazzy node that drives a regular polygon
(e.g. a 6 cm square) and estimates each side and each turn with the MPU6050.

Sequence (for each of the N sides):
  1. TARE     call <imu>/tare → the current rest reading becomes zero
              (re-done at every vertex if retare_each_segment, so drift
              does not carry over from one segment to the next)
  2. FORWARD  cmd_vel v = linear_speed.
              stop_mode time (default): stop after side_length / real speed
                (measured_linear_speed, or linear_speed if 0).
              stop_mode imu: stop when the IMU distance reaches the side.
              Distance from the IMU (always reported):
                v_imu += a_fwd · dt ,  d_imu += v_imu · dt
  3. PAUSE    robot stopped; IMU keeps integrating the braking phase. At the
              end the robot is at rest, so v must be 0: any residual v is
              drift and is removed assuming a constant bias (ZUPT):
                d_zupt = d_imu − v_residual · T / 2
  4. TURN     cmd_vel ω = ±angular_speed, slowing to angular_speed_slow in
              the last turn_slow_zone_deg. Angle from the gyro:
                θ += ω_z · dt
              stop when |θ| ≥ 360°/N − early_stop. With adaptive_early_stop
              the early_stop is corrected after every turn with the measured
              overshoot, so the turns converge to the target.
  5. PAUSE

Each segment is logged and published on trajectory/result (JSON), and the
estimated path on trajectory/path (nav_msgs/Path) for RViz.

Subscribes:
  <imu_topic>          sensor_msgs/Imu   (default mpu6050/imu/data_raw, tared)
Publishes:
  cmd_vel              geometry_msgs/Twist
  trajectory/path      nav_msgs/Path     frame <ns>/trajectory_origin
  trajectory/result    std_msgs/String   JSON per segment + summary
Services:
  trajectory/start     std_srvs/Trigger
  trajectory/stop      std_srvs/Trigger
Client:
  <tare_service>       std_srvs/Trigger  (default mpu6050/tare)

LIMITS: distance comes from a double integral of acceleration. Motor
vibration and the small pitch of the chassis when it accelerates (1° of
tilt = 0.17 m/s² of fake acceleration) make it drift by tens of cm in a few
seconds, so it is NOT used to stop the sides by default; the ZUPT
correction only removes the constant part of that drift. Turns from the
gyro are reliable and are what the node controls on.
"""

import json
import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, PoseStamped
from nav_msgs.msg import Path
from sensor_msgs.msg import Imu
from std_msgs.msg import String
from std_srvs.srv import Trigger


IDLE, TARE, SETTLE, FORWARD, PAUSE_F, TURN, PAUSE_T, DONE = range(8)
STATE_NAMES = ['IDLE', 'TARE', 'SETTLE', 'FORWARD', 'PAUSE_F', 'TURN', 'PAUSE_T', 'DONE']


class PolygonTrajectoryNode(Node):

    def __init__(self):
        super().__init__('polygon_trajectory_node')

        # ── Parameters ──
        # Polygon
        self.declare_parameter('sides',               4)
        self.declare_parameter('side_length_m',       0.06)
        self.declare_parameter('turn_left',           True)
        self.declare_parameter('final_turn',          True)   # turn at the last vertex → back to start heading
        self.declare_parameter('auto_start',          False)

        # Motion (keep ω·wheel_base/2 above the motor deadband: 0.03 m/s)
        self.declare_parameter('linear_speed',          0.04)   # m/s (cmd_vel)
        self.declare_parameter('measured_linear_speed', 0.0)    # m/s real speed (ruler); 0 → linear_speed
        self.declare_parameter('angular_speed',         0.9)    # rad/s (cmd_vel)
        self.declare_parameter('angular_speed_slow',    0.75)   # rad/s near the end of the turn
        self.declare_parameter('turn_slow_zone_deg',    30.0)   # slow down in the last N degrees
        self.declare_parameter('adaptive_early_stop',   True)   # learn the overshoot turn by turn
        self.declare_parameter('stop_mode',             'time') # time | imu  (forward segments)
        self.declare_parameter('timeout_factor',      2.5)    # abort a segment after factor × expected time
        self.declare_parameter('side_early_stop_m',   0.005)  # compensate coasting after cmd stop
        self.declare_parameter('turn_early_stop_deg', 20.0)   # initial overshoot compensation
        self.declare_parameter('pause_s',             1.0)    # stop between segments
        self.declare_parameter('settle_s',            0.5)    # after tare, before moving

        # IMU
        self.declare_parameter('imu_topic',           'mpu6050/imu/data_raw')
        self.declare_parameter('tare_service',        'mpu6050/tare')
        self.declare_parameter('retare_each_segment', True)
        self.declare_parameter('forward_axis',        'x')    # IMU axis pointing to robot front: x|-x|y|-y
        self.declare_parameter('gyro_z_sign',         1.0)    # -1.0 if IMU Z points down
        self.declare_parameter('control_hz',          50.0)

        gp = lambda k: self.get_parameter(k).value  # noqa: E731
        self._n          = int(gp('sides'))
        self._side       = float(gp('side_length_m'))
        self._turn_sign  = 1.0 if gp('turn_left') else -1.0
        self._final_turn = gp('final_turn')
        self._v_cmd      = float(gp('linear_speed'))
        self._w_cmd      = float(gp('angular_speed'))
        self._w_slow     = float(gp('angular_speed_slow'))
        self._slow_zone  = math.radians(float(gp('turn_slow_zone_deg')))
        self._adaptive   = gp('adaptive_early_stop')
        v_real           = float(gp('measured_linear_speed'))
        self._v_real     = v_real if v_real > 0.0 else self._v_cmd
        self._stop_mode  = gp('stop_mode')
        self._to_factor  = float(gp('timeout_factor'))
        self._early_stop = math.radians(float(gp('turn_early_stop_deg')))
        self._side_early = float(gp('side_early_stop_m'))
        self._pause_s    = float(gp('pause_s'))
        self._settle_s   = float(gp('settle_s'))
        self._retare     = gp('retare_each_segment')
        self._gz_sign    = float(gp('gyro_z_sign'))
        control_hz       = float(gp('control_hz'))

        axes = {'x': (0, 1.0), '-x': (0, -1.0), 'y': (1, 1.0), '-y': (1, -1.0)}
        fwd = gp('forward_axis')
        if fwd not in axes:
            self.get_logger().error(f'forward_axis "{fwd}" invalid — using "x".')
            fwd = 'x'
        self._fwd_idx, self._fwd_sign = axes[fwd]
        if self._stop_mode not in ('imu', 'time'):
            self.get_logger().error(f'stop_mode "{self._stop_mode}" invalid — using "time".')
            self._stop_mode = 'time'

        self._turn_target = 2.0 * math.pi / self._n          # exterior angle
        self._t_side      = self._side / self._v_real        # expected time per side
        self._t_turn      = self._turn_target / self._w_cmd  # expected time per turn

        ns = self.get_namespace().strip('/')
        self._path_frame = f'{ns}/trajectory_origin' if ns else 'trajectory_origin'

        # ── State ──
        self._state      = IDLE
        self._t_state    = self.get_clock().now()
        self._seg        = 0          # side index 0..n-1
        self._next_after_tare = FORWARD
        self._tare_future = None
        self._last_imu_t = None
        self._reset_estimates()
        self._results    = []
        self._seg_x0 = self._seg_y0 = 0.0

        # ── ROS I/O ──
        self._cmd_pub    = self.create_publisher(Twist, 'cmd_vel', 10)
        self._path_pub   = self.create_publisher(Path, 'trajectory/path', 10)
        self._res_pub    = self.create_publisher(String, 'trajectory/result', 10)
        self.create_subscription(Imu, gp('imu_topic'), self._imu_cb, 50)
        self._tare_cli   = self.create_client(Trigger, gp('tare_service'))
        self.create_service(Trigger, 'trajectory/start', self._start_cb)
        self.create_service(Trigger, 'trajectory/stop',  self._stop_cb)
        self._timer      = self.create_timer(1.0 / control_hz, self._control_cb)

        self.get_logger().info(
            f'Polygon trajectory ready — {self._n} sides × {self._side * 100:.1f} cm, '
            f'turn {math.degrees(self._turn_target):.1f}° {"left" if self._turn_sign > 0 else "right"}, '
            f'v={self._v_cmd} m/s (real {self._v_real}), ω={self._w_cmd}/{self._w_slow} rad/s, '
            f'stop_mode={self._stop_mode}. '
            f'Start with: ros2 service call trajectory/start std_srvs/srv/Trigger')

        if gp('auto_start'):
            self._start()

    # ── Estimation (IMU callback) ─────────────────────────────────────────────

    def _reset_estimates(self):
        self._x = self._y = self._yaw = 0.0   # estimated pose (from start)
        self._v_imu = 0.0                     # forward speed of current segment
        self._d_imu = 0.0                     # distance of current segment
        self._t_int = 0.0                     # integration time of current segment
        self._theta = 0.0                     # angle of current turn
        self._path  = []

    def _imu_cb(self, msg: Imu):
        now = self.get_clock().now()
        dt  = 0.0 if self._last_imu_t is None else (now - self._last_imu_t).nanoseconds * 1e-9
        self._last_imu_t = now
        if dt <= 0.0 or dt > 0.2:
            return

        a = (msg.linear_acceleration.x, msg.linear_acceleration.y)
        a_fwd = self._fwd_sign * a[self._fwd_idx]
        w     = self._gz_sign * msg.angular_velocity.z

        if self._state in (FORWARD, PAUSE_F):
            self._t_int += dt
            self._v_imu += a_fwd * dt
            step = self._v_imu * dt
            self._d_imu += step
            self._x += step * math.cos(self._yaw)
            self._y += step * math.sin(self._yaw)
        elif self._state in (TURN, PAUSE_T):
            self._theta += w * dt
            self._yaw   += w * dt

    # ── Services ──────────────────────────────────────────────────────────────

    def _start(self) -> bool:
        if self._state not in (IDLE, DONE):
            return False
        self._seg = 0
        self._results = []
        self._reset_estimates()
        self._add_path_point()
        self._request_tare(next_state=FORWARD)
        self.get_logger().info('Trajectory started.')
        return True

    def _start_cb(self, request, response):
        response.success = self._start()
        response.message = 'started' if response.success else \
            f'busy (state {STATE_NAMES[self._state]})'
        return response

    def _stop_cb(self, request, response):
        self._set_state(IDLE)
        self._publish_cmd(0.0, 0.0)
        self.get_logger().warn('Trajectory aborted.')
        response.success = True
        response.message = 'stopped'
        return response

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_state(self, s):
        self._state   = s
        self._t_state = self.get_clock().now()

    def _elapsed(self) -> float:
        return (self.get_clock().now() - self._t_state).nanoseconds * 1e-9

    def _publish_cmd(self, v, w):
        t = Twist()
        t.linear.x  = float(v)
        t.angular.z = float(w)
        self._cmd_pub.publish(t)

    def _request_tare(self, next_state):
        self._next_after_tare = next_state
        if self._tare_cli.service_is_ready():
            self._tare_future = self._tare_cli.call_async(Trigger.Request())
        else:
            self._tare_future = None
            self.get_logger().warn('Tare service not available — continuing without tare.')
        self._set_state(TARE)

    def _add_path_point(self):
        p = PoseStamped()
        p.header.frame_id = self._path_frame
        p.header.stamp    = self.get_clock().now().to_msg()
        p.pose.position.x = self._x
        p.pose.position.y = self._y
        p.pose.orientation.z = math.sin(self._yaw / 2.0)
        p.pose.orientation.w = math.cos(self._yaw / 2.0)
        self._path.append(p)

        path = Path()
        path.header.frame_id = self._path_frame
        path.header.stamp    = p.header.stamp
        path.poses = list(self._path)
        self._path_pub.publish(path)

    def _report(self, data: dict):
        self._results.append(data)
        msg = String()
        msg.data = json.dumps(data)
        self._res_pub.publish(msg)

    # ── State machine ─────────────────────────────────────────────────────────

    def _control_cb(self):
        s, t = self._state, self._elapsed()

        if s in (IDLE, DONE):
            return

        if s == TARE:
            self._publish_cmd(0.0, 0.0)
            done = self._tare_future is None or self._tare_future.done()
            if done or t > 5.0:
                if not done:
                    self.get_logger().warn('Tare timed out — continuing.')
                self._set_state(SETTLE)
            return

        if s == SETTLE:
            self._publish_cmd(0.0, 0.0)
            if t >= self._settle_s:
                self._v_imu = self._d_imu = self._theta = self._t_int = 0.0
                self._seg_x0, self._seg_y0 = self._x, self._y
                self._set_state(self._next_after_tare)
            return

        if s == FORWARD:
            if self._stop_mode == 'imu':
                reached = self._d_imu >= self._side - self._side_early
            else:
                reached = t >= self._t_side
            timeout = t >= self._to_factor * self._t_side
            if reached or timeout:
                self._publish_cmd(0.0, 0.0)
                self._fwd_time    = t
                self._fwd_timeout = timeout and not reached
                self._set_state(PAUSE_F)
            else:
                self._publish_cmd(self._v_cmd, 0.0)
            return

        if s == PAUSE_F:
            self._publish_cmd(0.0, 0.0)
            if t >= self._pause_s:
                # ZUPT: robot is at rest → residual v is drift (assume constant bias)
                d_zupt = self._d_imu - self._v_imu * self._t_int / 2.0
                # Re-place the path point with the corrected distance
                self._x = self._seg_x0 + d_zupt * math.cos(self._yaw)
                self._y = self._seg_y0 + d_zupt * math.sin(self._yaw)
                model_cm = self._v_real * self._fwd_time * 100
                self._report({
                    'segment': f'side {self._seg + 1}/{self._n}',
                    'target_cm': round(self._side * 100, 2),
                    'imu_zupt_cm': round(d_zupt * 100, 2),
                    'imu_raw_cm': round(self._d_imu * 100, 2),
                    'model_cm': round(model_cm, 2),
                    'time_s': round(self._fwd_time, 2),
                    'v_residual_cm_s': round(self._v_imu * 100, 2),
                    'timeout': self._fwd_timeout,
                })
                self.get_logger().info(
                    f'Side {self._seg + 1}/{self._n}: IMU(zupt) {d_zupt * 100:.1f} cm '
                    f'[raw {self._d_imu * 100:.1f}] (target {self._side * 100:.1f}, '
                    f'model {model_cm:.1f}) v_residual={self._v_imu * 100:+.2f} cm/s'
                    + ('  [TIMEOUT]' if self._fwd_timeout else ''))
                self._add_path_point()

                last = self._seg == self._n - 1
                if last and not self._final_turn:
                    self._finish()
                elif self._retare:
                    self._request_tare(next_state=TURN)
                else:
                    self._v_imu = self._theta = 0.0
                    self._set_state(TURN)
            return

        if s == TURN:
            stop_at = self._turn_target - self._early_stop
            reached = abs(self._theta) >= stop_at
            timeout = t >= self._to_factor * self._t_turn
            if reached or timeout:
                self._publish_cmd(0.0, 0.0)
                self._turn_time    = t
                self._turn_timeout = timeout and not reached
                self._set_state(PAUSE_T)
            else:
                w = self._w_slow if abs(self._theta) >= stop_at - self._slow_zone else self._w_cmd
                self._publish_cmd(0.0, self._turn_sign * w)
            return

        if s == PAUSE_T:
            self._publish_cmd(0.0, 0.0)
            if t >= self._pause_s:
                early_used = self._early_stop
                if self._adaptive and not self._turn_timeout:
                    # overshoot error → move the stop point by that amount
                    err = abs(self._theta) - self._turn_target
                    self._early_stop = min(max(self._early_stop + err, 0.0),
                                           0.8 * self._turn_target)
                self._report({
                    'segment': f'turn {self._seg + 1}/{self._n}',
                    'target_deg': round(math.degrees(self._turn_target), 1),
                    'imu_deg': round(math.degrees(abs(self._theta)), 1),
                    'early_stop_deg': round(math.degrees(early_used), 1),
                    'next_early_stop_deg': round(math.degrees(self._early_stop), 1),
                    'time_s': round(self._turn_time, 2),
                    'timeout': self._turn_timeout,
                })
                self.get_logger().info(
                    f'Turn {self._seg + 1}/{self._n}: IMU {math.degrees(abs(self._theta)):.1f}° '
                    f'(target {math.degrees(self._turn_target):.1f}°, early stop '
                    f'{math.degrees(early_used):.1f}° → next {math.degrees(self._early_stop):.1f}°)'
                    + ('  [TIMEOUT]' if self._turn_timeout else ''))
                self._add_path_point()

                self._seg += 1
                if self._seg >= self._n:
                    self._finish()
                elif self._retare:
                    self._request_tare(next_state=FORWARD)
                else:
                    self._v_imu = self._d_imu = self._t_int = 0.0
                    self._seg_x0, self._seg_y0 = self._x, self._y
                    self._set_state(FORWARD)
            return

    def _finish(self):
        self._publish_cmd(0.0, 0.0)
        close_err = math.hypot(self._x, self._y)
        summary = {
            'segment': 'summary',
            'sides': self._n,
            'side_target_cm': round(self._side * 100, 2),
            'end_x_cm': round(self._x * 100, 2),
            'end_y_cm': round(self._y * 100, 2),
            'end_yaw_deg': round(math.degrees(self._yaw), 1),
            'closure_error_cm': round(close_err * 100, 2),
        }
        self._report(summary)
        self.get_logger().info(
            f'Trajectory done — estimated end ({self._x * 100:.1f}, {self._y * 100:.1f}) cm, '
            f'yaw {math.degrees(self._yaw):.1f}°, closure error {close_err * 100:.1f} cm')
        self._set_state(DONE)

    def destroy_node(self):
        try:
            self._publish_cmd(0.0, 0.0)
        except Exception:
            pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = PolygonTrajectoryNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
