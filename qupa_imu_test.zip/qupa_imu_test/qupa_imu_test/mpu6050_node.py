#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mpu6050_node — ROS2 Jazzy node for the MPU6050 6-axis IMU (I2C).

Reads accelerometer, gyroscope and die temperature in a single 14-byte
burst and publishes them at a configurable rate.

Tare ("encerado"):
  With the robot at rest, the node averages N raw samples and stores them
  as the reference (accel incl. gravity, and gyro bias). Every published
  sample is   value = raw − reference,   so at rest accel ≈ 0 and gyro ≈ 0.
  The reference is taken at startup (tare_on_start) and can be re-taken at
  any time with the 'tare' service — e.g. before running a trajectory.
  NOTE: because gravity is part of the reference, the tared accel is only
  valid while the robot stays on the same flat surface (no tilt).

The MPU6050 has no magnetometer and no orientation is fused, so
orientation_covariance[0] = -1 (REP-145).

Default wiring: I2C bus 1 (/dev/i2c-1), address 0x68 (AD0 low).

Publishes (relative to the node namespace, e.g. /qupa_3A/mpu6050/):
  imu/data_raw      sensor_msgs/Imu          — tared accel [m/s²], gyro [rad/s]
  imu/temperature   sensor_msgs/Temperature  — die temperature [°C]

Services:
  tare              std_srvs/Trigger         — re-take the rest reference

Frame: 'frame_id' parameter (default <namespace>/imu_link).
"""

import math
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu, Temperature
from std_srvs.srv import Trigger

try:
    import smbus2
    SMBUS_AVAILABLE = True
except ImportError:
    SMBUS_AVAILABLE = False


# ── Registers (MPU6050) ──────────────────────────────────────────────────────
REG_SMPLRT_DIV   = 0x19
REG_CONFIG       = 0x1A
REG_GYRO_CONFIG  = 0x1B
REG_ACCEL_CONFIG = 0x1C
REG_ACCEL_XOUT_H = 0x3B   # start of 14-byte burst: accel(6) temp(2) gyro(6)
REG_PWR_MGMT_1   = 0x6B
REG_WHO_AM_I     = 0x75

WHO_AM_I_VALUES  = (0x68, 0x70, 0x72, 0x98)   # genuine + common clones

G = 9.80665

# full-scale setting → (register bits, LSB per unit)
ACCEL_RANGES = {2: (0x00, 16384.0), 4: (0x08, 8192.0),
                8: (0x10, 4096.0),  16: (0x18, 2048.0)}          # ±g
GYRO_RANGES  = {250: (0x00, 131.0), 500: (0x08, 65.5),
                1000: (0x10, 32.8), 2000: (0x18, 16.4)}          # ±°/s


def _to_int16(hi: int, lo: int) -> int:
    v = (hi << 8) | lo
    return v - 65536 if v & 0x8000 else v


# ── Low-level sensor driver ───────────────────────────────────────────────────

class MPU6050:
    """Minimal smbus2 driver for the MPU6050."""

    def __init__(self, bus: int, address: int, accel_range: int,
                 gyro_range: int, dlpf_cfg: int, sample_rate_div: int):
        if accel_range not in ACCEL_RANGES:
            raise ValueError(f'accel_range must be one of {list(ACCEL_RANGES)}')
        if gyro_range not in GYRO_RANGES:
            raise ValueError(f'gyro_range must be one of {list(GYRO_RANGES)}')

        self.bus     = smbus2.SMBus(bus)
        self.address = address

        accel_bits, self._accel_lsb = ACCEL_RANGES[accel_range]
        gyro_bits,  self._gyro_lsb  = GYRO_RANGES[gyro_range]

        who = self.bus.read_byte_data(address, REG_WHO_AM_I)
        self.who_am_i = who

        # Wake up, clock source = PLL with X-gyro reference (more stable)
        self.bus.write_byte_data(address, REG_PWR_MGMT_1, 0x01)
        time.sleep(0.1)
        self.bus.write_byte_data(address, REG_SMPLRT_DIV, sample_rate_div & 0xFF)
        self.bus.write_byte_data(address, REG_CONFIG, dlpf_cfg & 0x07)
        self.bus.write_byte_data(address, REG_GYRO_CONFIG, gyro_bits)
        self.bus.write_byte_data(address, REG_ACCEL_CONFIG, accel_bits)
        time.sleep(0.05)

    def read(self):
        """Return (accel_xyz [m/s²], gyro_xyz [rad/s], temp [°C])."""
        d = self.bus.read_i2c_block_data(self.address, REG_ACCEL_XOUT_H, 14)

        ax = _to_int16(d[0],  d[1])  / self._accel_lsb * G
        ay = _to_int16(d[2],  d[3])  / self._accel_lsb * G
        az = _to_int16(d[4],  d[5])  / self._accel_lsb * G
        t  = _to_int16(d[6],  d[7])  / 340.0 + 36.53
        gx = math.radians(_to_int16(d[8],  d[9])  / self._gyro_lsb)
        gy = math.radians(_to_int16(d[10], d[11]) / self._gyro_lsb)
        gz = math.radians(_to_int16(d[12], d[13]) / self._gyro_lsb)

        return (ax, ay, az), (gx, gy, gz), t

    def close(self):
        try:
            self.bus.close()
        except Exception:
            pass


# ── ROS2 node ─────────────────────────────────────────────────────────────────

class MPU6050Node(Node):

    def __init__(self):
        super().__init__('mpu6050_node')

        # ── Parameters ──
        self.declare_parameter('i2c_bus',             1)
        self.declare_parameter('address',             0x68)
        self.declare_parameter('frame_id',            '')     # '' → <namespace>/imu_link
        self.declare_parameter('loop_hz',             50.0)
        self.declare_parameter('accel_range',         2)      # ±g: 2 | 4 | 8 | 16
        self.declare_parameter('gyro_range',          250)    # ±°/s: 250 | 500 | 1000 | 2000
        self.declare_parameter('dlpf_cfg',            3)      # 0..6 (3 ≈ 44 Hz bandwidth)
        self.declare_parameter('sample_rate_div',     0)
        self.declare_parameter('tare_on_start',       True)   # robot must be still at startup
        self.declare_parameter('tare_samples',        200)
        self.declare_parameter('publish_temperature', True)
        self.declare_parameter('accel_variance',      0.0004)   # (m/s²)²
        self.declare_parameter('gyro_variance',       0.00003)  # (rad/s)²

        self._bus_id       = self.get_parameter('i2c_bus').value
        self._address      = self.get_parameter('address').value
        frame_id           = self.get_parameter('frame_id').value
        loop_hz            = self.get_parameter('loop_hz').value
        self._accel_range  = self.get_parameter('accel_range').value
        self._gyro_range   = self.get_parameter('gyro_range').value
        self._dlpf_cfg     = self.get_parameter('dlpf_cfg').value
        self._smplrt_div   = self.get_parameter('sample_rate_div').value
        tare_on_start      = self.get_parameter('tare_on_start').value
        self._tare_samples = self.get_parameter('tare_samples').value
        self._pub_temp     = self.get_parameter('publish_temperature').value
        accel_var          = self.get_parameter('accel_variance').value
        gyro_var           = self.get_parameter('gyro_variance').value

        if not frame_id:
            ns = self.get_namespace().strip('/')
            frame_id = f'{ns}/imu_link' if ns else 'imu_link'
        self._frame_id = frame_id

        self._accel_cov = [accel_var, 0.0, 0.0, 0.0, accel_var, 0.0, 0.0, 0.0, accel_var]
        self._gyro_cov  = [gyro_var,  0.0, 0.0, 0.0, gyro_var,  0.0, 0.0, 0.0, gyro_var]

        # Tare reference (raw units: m/s², rad/s)
        self._accel_ref = (0.0, 0.0, 0.0)
        self._gyro_ref  = (0.0, 0.0, 0.0)
        self._consecutive_errors = 0

        # ── Hardware ──
        self._sensor = None
        if not SMBUS_AVAILABLE:
            self.get_logger().error('smbus2 not found — cannot open I2C bus.')
            return

        try:
            self._sensor = self._init_sensor()
        except Exception as e:
            self.get_logger().error(
                f'MPU6050 init failed on /dev/i2c-{self._bus_id} '
                f'@ 0x{self._address:02X}: {e}')
            return

        if tare_on_start:
            self._tare(self._tare_samples)

        # ── Publishers / services ──
        self._imu_pub  = self.create_publisher(Imu, 'imu/data_raw', 10)
        self._temp_pub = (self.create_publisher(Temperature, 'imu/temperature', 10)
                          if self._pub_temp else None)
        self._tare_srv = self.create_service(Trigger, 'tare', self._tare_cb)

        self._timer = self.create_timer(1.0 / loop_hz, self._timer_cb)
        self.get_logger().info(
            f'MPU6050 node ready @ {loop_hz:.1f} Hz (frame: {self._frame_id})')

    def _init_sensor(self):
        sensor = MPU6050(self._bus_id, self._address, self._accel_range,
                         self._gyro_range, self._dlpf_cfg, self._smplrt_div)
        if sensor.who_am_i not in WHO_AM_I_VALUES:
            self.get_logger().warn(
                f'Unexpected WHO_AM_I 0x{sensor.who_am_i:02X} — continuing anyway.')
        self.get_logger().info(
            f'MPU6050 initialized on /dev/i2c-{self._bus_id} @ 0x{self._address:02X} '
            f'(±{self._accel_range} g, ±{self._gyro_range} °/s)')
        return sensor

    # ── Tare ("encerado") ─────────────────────────────────────────────────────

    def _tare(self, n: int) -> bool:
        """Average n raw samples at rest and store them as the reference."""
        self.get_logger().info(f'Tare: averaging {n} samples — keep the robot still...')
        acc = [0.0] * 3
        gyr = [0.0] * 3
        ok = 0
        for _ in range(n):
            try:
                a, g, _ = self._sensor.read()
            except OSError:
                continue
            for i in range(3):
                acc[i] += a[i]
                gyr[i] += g[i]
            ok += 1
            time.sleep(0.005)

        if ok < max(1, n // 2):
            self.get_logger().warn(f'Tare failed ({ok}/{n} good samples) — reference unchanged.')
            return False

        self._accel_ref = tuple(x / ok for x in acc)
        self._gyro_ref  = tuple(x / ok for x in gyr)
        ax, ay, az = self._accel_ref
        gx, gy, gz = (math.degrees(x) for x in self._gyro_ref)
        self.get_logger().info(
            f'Tare done — accel ref [m/s²]: x={ax:+.3f} y={ay:+.3f} z={az:+.3f} | '
            f'gyro ref [°/s]: x={gx:+.3f} y={gy:+.3f} z={gz:+.3f}')
        return True

    def _tare_cb(self, request, response):
        if self._sensor is None:
            response.success = False
            response.message = 'Sensor not initialized'
            return response
        response.success = self._tare(self._tare_samples)
        response.message = (f'accel_ref={[round(x, 4) for x in self._accel_ref]} '
                            f'gyro_ref={[round(x, 5) for x in self._gyro_ref]}')
        return response

    # ── Loop ──────────────────────────────────────────────────────────────────

    def _timer_cb(self):
        if self._sensor is None:
            return

        try:
            (ax, ay, az), (gx, gy, gz), temp = self._sensor.read()
            self._consecutive_errors = 0
        except OSError as e:
            self._consecutive_errors += 1
            self.get_logger().warn(f'I2C read error #{self._consecutive_errors}: {e}')
            if self._consecutive_errors >= 5:
                self.get_logger().warn('Reinitializing MPU6050...')
                self._sensor.close()
                time.sleep(1.0)
                try:
                    self._sensor = self._init_sensor()
                    self._consecutive_errors = 0
                except Exception as re:
                    self.get_logger().error(f'Reinit failed: {re}')
            return

        rax, ray, raz = self._accel_ref
        rgx, rgy, rgz = self._gyro_ref
        now = self.get_clock().now().to_msg()

        imu = Imu()
        imu.header.stamp    = now
        imu.header.frame_id = self._frame_id

        # No orientation estimate (REP-145)
        imu.orientation_covariance[0] = -1.0

        imu.angular_velocity.x = gx - rgx
        imu.angular_velocity.y = gy - rgy
        imu.angular_velocity.z = gz - rgz
        imu.angular_velocity_covariance = self._gyro_cov

        imu.linear_acceleration.x = ax - rax
        imu.linear_acceleration.y = ay - ray
        imu.linear_acceleration.z = az - raz
        imu.linear_acceleration_covariance = self._accel_cov

        self._imu_pub.publish(imu)

        if self._temp_pub is not None:
            t = Temperature()
            t.header.stamp    = now
            t.header.frame_id = self._frame_id
            t.temperature     = temp
            t.variance        = 0.0
            self._temp_pub.publish(t)

    def destroy_node(self):
        if self._sensor is not None:
            self._sensor.close()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = MPU6050Node()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
