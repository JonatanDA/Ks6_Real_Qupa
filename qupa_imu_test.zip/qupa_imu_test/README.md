# qupa_imu_test

Paquete de prueba: MPU6050 con encerado + trayectoria de polígonos estimada con el IMU.

## Instalar (en el robot)

```bash
cd ~/ros2_ws/src            # tu workspace
unzip qupa_imu_test.zip     # deja la carpeta qupa_imu_test/ aquí
cd ~/ros2_ws
colcon build --packages-select qupa_imu_test --symlink-install
source install/setup.bash
```

Requiere `qupa_hardware` (para `motor_node`) y `smbus2` (ya instalado para el IR).

## Probar

```bash
# 1. Robot quieto en el piso (el encerado se hace al arrancar)
ros2 launch qupa_imu_test trajectory_test.launch.py

# 2. Otra terminal: datos encerados (en reposo ≈ 0)
ros2 topic echo /qupa_3A/mpu6050/imu/data_raw

# 3. Resultados y arranque del cuadrado
ros2 topic echo /qupa_3A/trajectory/result
ros2 service call /qupa_3A/trajectory/start std_srvs/srv/Trigger

# Abortar
ros2 service call /qupa_3A/trajectory/stop std_srvs/srv/Trigger

# Re-encerar a mano
ros2 service call /qupa_3A/mpu6050/tare std_srvs/srv/Trigger
```

Si `hardware.launch.py` ya está corriendo con motor_node, lanza con `with_motors:=false`.

Parámetros del polígono (lados, largo, velocidades, eje frontal) en `config/polygon_trajectory.yaml`.
