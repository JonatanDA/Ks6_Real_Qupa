from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'qupa_imu_test'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='David Torres',
    maintainer_email='davatorr@espol.edu.ec',
    description='MPU6050 tare + polygon trajectory test for QUPA',
    license='MIT',
    entry_points={
        'console_scripts': [
            'mpu6050            = qupa_imu_test.mpu6050_node:main',
            'polygon_trajectory = qupa_imu_test.polygon_trajectory_node:main',
        ],
    },
)
